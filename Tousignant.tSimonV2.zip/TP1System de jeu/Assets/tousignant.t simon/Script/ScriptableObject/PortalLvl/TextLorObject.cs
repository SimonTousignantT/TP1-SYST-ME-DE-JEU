using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "DataPortalText", menuName = "ScriptableObjects/TextPortal", order = 1)]
public class TextLorObject : ScriptableObject
{
    // Start is called before the first frame update
    public string[] m_textLvl = { " ", " ", " ", " " };
  
}
